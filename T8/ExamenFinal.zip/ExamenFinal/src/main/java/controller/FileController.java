package controller;

import model.Libros;
import model.Biblioteca;
import model.Autores;

import dao.AutoresDAO;
import dao.LibrosDAO;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;


import model.Biblioteca;
import model.Autores;
import model.Libros;
import dao.LibrosDAO;
import org.hibernate.SessionFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

import static database.HibernateUtil.sessionFactory;


public class FileController {


        private final LibrosDAO librosDAO;

        public FileController() {
            this.librosDAO = new LibrosDAO( sessionFactory);
        }




        public void exportarACSV(String rutaArchivo, List<Libros> listaLibros) throws IOException {
            Path path = Path.of(rutaArchivo);

            // Crear directorios intermedios si no existen
            if (path.getParent() != null) {
                Files.createDirectories(path.getParent());
            }

            List<String> lineas = new ArrayList<>();
            lineas.add();

            for (Libros libros : listaLibros) {
            }

            Files.write(path, lineas, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING);

            System.out.printf("  [CSV] %d libros exportados a: %s%n",
                    listaLibros.size(), path.toAbsolutePath());
        }



    }
