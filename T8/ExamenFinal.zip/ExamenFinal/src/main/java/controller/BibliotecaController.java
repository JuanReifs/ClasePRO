package controller;
import database.HibernateUtil;
import jakarta.transaction.SystemException;
import model.Libros;
import model.Biblioteca;
import model.Autores;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import  dao.LibrosDAO;
import dao.AutoresDAO;

import java.util.ArrayList;

public class BibliotecaController {
    private ArrayList<Libros> libros;
    private LibrosDAO librosDAO;

    public BibliotecaController() {
        ArrayList<Libros> libros = new ArrayList<>();
    }

    public void guardarLibro(Libros libros){
        System.out.println("Autor");
        System.out.println("NumPags");
        System.out.println("Tipo");
        System.out.println("año");
        System.out.println("");

        librosDAO.guardar(libros);


    }
}
