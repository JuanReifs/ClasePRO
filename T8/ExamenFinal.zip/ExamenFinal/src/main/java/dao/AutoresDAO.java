package dao;

import com.mysql.cj.xdevapi.SessionFactory;
import database.HibernateUtil;
import model.Autores;
import org.hibernate.Session;
import org.hibernate.mapping.List;

public class AutoresDAO {
    private SessionFactory sessionFactory;

    public AutoresDAO(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }


    }

