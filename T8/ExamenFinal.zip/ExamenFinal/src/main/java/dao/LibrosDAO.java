package dao;
import database.HibernateUtil;
import jakarta.transaction.SystemException;
import model.Libros;
import model.Biblioteca;
import model.Autores;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class LibrosDAO {
    private SessionFactory sessionFactory;
    private Libros libros;
    private Biblioteca biblioteca;

    public LibrosDAO(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }


    public Libros  guardar (Libros libros) {
        Transaction tx = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            tx = session.beginTransaction();
             session.persist(libros);
            tx.commit();
             return libros;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Error al guardar el coche: " + e.getMessage(), e);
        }
    }



    }





