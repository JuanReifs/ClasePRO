package model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Biblioteca")

public class Biblioteca {

    @Column(name = "calle", nullable = false, length = 100)
    private String calle;

    @Column(name = "localidad", nullable = false, length = 100)
    private String localidad;

    @Column(name = "provincia", nullable = false, length = 100)
    private String provincia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_marca", nullable = false)
    private Libros libro;
}
