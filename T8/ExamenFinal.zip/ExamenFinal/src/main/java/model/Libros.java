package model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Biblioteca")
public class Libros {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ISBN;

    @Column(name = "autor", nullable = false, length = 100)
    private String autor;

    @Column(name = "numPags", nullable = false)
    private int numPags;

    @Column(name = "tipo", nullable = false)
    private String tipo;

    @Column(name = "año", nullable = false)
    private String anioPublicacion;

    @OneToMany(mappedBy = "Autor", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Autores> Autores = new ArrayList<>();

    @OneToMany(mappedBy = "Autor", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Biblioteca> Biblioteca = new ArrayList<>();

    public Libros(String autor, int numPags, String tipo, String anioPublicacion, List<Autores> autores, List<Biblioteca> biblioteca) {
        this.autor = autor;
        this.numPags = numPags;
        this.tipo = tipo;
        this.anioPublicacion = anioPublicacion;
        Autores = autores;
        Biblioteca = biblioteca;
    }
}
