package database;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

    public static final SessionFactory sessionFactory
            = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {
        try {
            Configuration configuration = new Configuration();
            // configuration.configure("hibernate.cfg.xml");
            configuration.configure();
            return configuration.buildSessionFactory();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        getSessionFactory().close();
    }
}











/*
public Coche guardar(Coche coche) {
    Transaction tx = null;
    try (Session session = HibernateUtil.getSessionFactory().openSession()) {
        tx = session.beginTransaction();
       // session.persist(coche);
        tx.commit();
        // return coche;
    } catch (Exception e) {
        if (tx != null) tx.rollback();
        throw new RuntimeException("Error al guardar el coche: " + e.getMessage(), e);
    }
}
 */